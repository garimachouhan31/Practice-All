import { message, test, user } from "./file1.js";
//import {user} from "./file1.js";

console.log(message);
console.log(user("GARIMA"));
let a = new test();

document.body.innerHTML = message;


//default function

import { default as gc} from "./file1.js";
gc();