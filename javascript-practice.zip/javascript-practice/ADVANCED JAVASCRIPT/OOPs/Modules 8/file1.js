export let message = "hello";

export function user(name)
{
   return `hello ${name}`; 
}

export class test{
    constructor(){
        console.log("constructor method");
    }
}

//export {message, user, test};


export default function(){
    console.log("default function");
}