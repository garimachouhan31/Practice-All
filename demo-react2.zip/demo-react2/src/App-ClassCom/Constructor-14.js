
import React from 'react'
class constructor extends React.Component{
  constructor()
  {
    super();
    this.state={
      name:"Anil sidhu"
    }
    console.warn("constructor")
  }
  render()
  {
    console.warn("render")
    return<div>
      <h1>Hello World {this.state.name}</h1>
    </div>
  }
}
export default constructor;