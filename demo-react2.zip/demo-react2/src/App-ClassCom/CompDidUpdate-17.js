
import React from 'react'
class compDidUpdate extends React.Component {
  constructor()
  {
    super();
    console.log("constructor")
    this.state={count : 0}
  }
  componentDidUpdate(preProps, preState,snapshot)
  {
    console.log("componentDidUpdate",preState.count , this.state.count)

    if(preState.count === this.state.count){
        alert("data is same");
    }

  }
  render()
  {
    console.log("render")

    return (
      <div className="App">
        <h4> {this.state.count}</h4>
        <button onClick={()=>this.setState({count : this.state.count+1})}>Update count</button>
        <button onClick={()=>this.setState({count : 1})}>check</button>
      </div>
    );
  }
}

export default compDidUpdate;