
import React from 'react'
class componentDidMount extends React.Component {
  constructor()
  {
    super();
    console.log("constructor")
    this.state={name:"Garima"}
  }
  componentDidMount()
  {
    console.log("componentDidMount")

  }
  render()
  {
    console.log("render")

    return (
      <div className="App">
        <h4> {this.state.name}</h4>
        <button onClick={()=>this.setState({name:"Sidhu"})}>Update</button>
      </div>
    );
  }
}

export default componentDidMount;