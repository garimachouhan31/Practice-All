import React from 'react'
import CWU2 from './CWU2';
class CompWillUnmount extends React.Component{

    constructor()
  {
    super();
    this.state={
      show:true
    }
  }
   
    render()
    {
        return(
            <div className="App">
        {
          this.state.show?<CWU2/>
          :<h4>Component is removed</h4>
        }
        <button onClick={()=>this.setState({show:false})}> Toogle Student Component</button>
      </div>
    
        )
    }
}

export default CompWillUnmount;