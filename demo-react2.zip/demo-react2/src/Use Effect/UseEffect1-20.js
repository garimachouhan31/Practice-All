
import React, { useEffect, useState } from 'react'
function UseEffect1() {
  const [count, setCount] = useState(0)
  useEffect(() => {
    console.log("use effect")
  })
  return (
    <div className="App">
      <h1> {count}</h1>
      <button onClick={() => setCount(count + 1)}>Update Counter</button>
    </div>
  );
}

export default UseEffect1;