import React from "react";

function HandleArrWithList() {
    const student = ["anil", "munna","rubina", "siddh"];
    return (
      <div className="App">
       <h4>map function</h4>
       {
        student.map((data)=>
            <h5>name : {data}</h5>
        )
       }
      </div>
    );
  }
  
  export default HandleArrWithList;