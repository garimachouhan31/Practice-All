import React from 'react'
import './App.css';
//import Constructor from './App-ClassCom/Constructor-14';
//import RenderLifecycle from './App-ClassCom/RenderLifecycle-15';
//import ComponentDidMount from './App-ClassCom/ComponentDidMount-16';
//import CompDidUpdate from './App-ClassCom/CompDidUpdate-17';
//import ShouldCompUpdate from './App-ClassCom/ShouldCompUpdate-18';
//import CompWillUnmount from './App-ClassCom/CompWillUnmount-19';
//import UseEffect1 from './Use Effect/UseEffect1-20';
//import UseEffect2 from './Use Effect/UseEffect2-21';
import CssTypes from './Style - Bootstrap/CssTypes-22'
import HandleArrWithList from './Style - Bootstrap/HandleArrWithList-23';
import ArrWithObject from './Style - Bootstrap/ArrEithObject-24';
import ListWithBootstrap from './Style - Bootstrap/ListWithBootstrap-25';
import NestedList from './Style - Bootstrap/NestedList-26';

function App() {
  //Render life cycle
  const [name,setName]=React.useState("Anil")
  return (
    <div className="App">
      {/* <Constructor/> */}

      {/* <h4>Render Life Cycle method</h4> */}
      {/* <button onClick={()=>setName("Sidhu")}>Update Name</button> */}
      {/* <RenderLifecycle/> */}

      {/* <h4>Component Did Mount</h4>
      <ComponentDidMount/> */}

      {/* <h4>Component did Update</h4>
      <CompDidUpdate/> */}

      {/* <h4>shouldComponentUpdate</h4>
      <ShouldCompUpdate/> */}

      {/* <h4>componentWillUnmount</h4>
      <CompWillUnmount/> */}

      {/* <h4>useEffect in React</h4>
        <UseEffect1/> */}

      {/* <h4>useEffect in React part 2</h4>  
        <UseEffect2/> */}

        <h2>Style with bootstrap</h2>
        <h4>Types of style</h4>
        <CssTypes/>

        <h4>Handle Array With List</h4>
        <HandleArrWithList/>

        <h4>data of list without using bootstrap table</h4>
        <ArrWithObject/>

        <h4>data of list with using bootstrap table</h4>
        <ListWithBootstrap/>

        <h4>Nested List</h4>
        <NestedList/>
    </div>
  );
}

export default App;
