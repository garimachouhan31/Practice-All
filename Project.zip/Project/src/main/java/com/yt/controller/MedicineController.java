package com.yt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yt.model.Medicine;
import com.yt.service.MedicineService;

@RestController
public class MedicineController {

	@Autowired
	private MedicineService medService;
	
	@PostMapping("/saveMed")
	public ResponseEntity<?>saveMedicine(@RequestBody Medicine medicine){
		return new ResponseEntity<>(medService.saveMedicine(medicine),HttpStatus.CREATED);
	}
	
	@GetMapping("/AllMed")
	public ResponseEntity<?>getAllMedicine(){
		return new ResponseEntity<>(medService.getAllMedicine(),HttpStatus.OK);
	}
	
	@GetMapping("/med/{id}")
	public ResponseEntity<?>getMedicineById(@PathVariable("id") Integer id){
		return new ResponseEntity<>(medService.getMedicineById(id),HttpStatus.OK);
	}
	
	@DeleteMapping("/DelMed/{id}")
	public ResponseEntity<?>deleteMedicine(@PathVariable("id") Integer id){
		return new ResponseEntity<>(medService.deleteMed(id),HttpStatus.OK);
	}
	
	@PostMapping("/editMed/{id}")
	public ResponseEntity<?>editMed(@RequestBody Medicine medicine,@PathVariable Integer id){
		return new ResponseEntity<>(medService.saveMedicine(medicine),HttpStatus.CREATED);
	}
}
