package com.yt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yt.model.Medicine;
import com.yt.repo.MedicineRepo;

@Service
public class MedicineServiceImpl implements MedicineService {

	@Autowired
	private MedicineRepo medicineRepo;
	
	@Override
	public Medicine saveMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		return medicineRepo.save(medicine);
	}

	@Override
	public List<Medicine> getAllMedicine() {
		// TODO Auto-generated method stub
		return medicineRepo.findAll();
	}

	@Override
	public Medicine getMedicineById(Integer id) {
		// TODO Auto-generated method stub
		return medicineRepo.findById(id).get();
	}

	@Override
	public String deleteMed(Integer id) {
		// TODO Auto-generated method stub
		Medicine medicine = medicineRepo.findById(id).get();
		
		if(medicine != null) {
			medicineRepo.delete(medicine);
			
			return "deleted successfully";
		}
		return "something wrong on server";
	}

	
}
