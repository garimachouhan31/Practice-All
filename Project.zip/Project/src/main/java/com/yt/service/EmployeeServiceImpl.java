package com.yt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yt.model.Employee;
import com.yt.model.Product;
import com.yt.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepo employeeRepo;
	
	public Employee saveEmployee(Employee employee) {
		return  employeeRepo.save(employee);
	}
	
	public List<Employee> getAllEmployee(){
		return employeeRepo.findAll();
	}
	
	public Employee getEmployeeById(Integer id) {
		return employeeRepo.findById(id).get();
	}
	
	public String deleteEmployee(Integer id) {
		Employee employee = employeeRepo.findById(id).get();
		
		if(employee != null) {
			employeeRepo.delete(employee);
			return "delete successfully";
		}
		return "something wrong";
	}

	@Override
	public Employee editEmp(Employee e, Integer id) {
Employee oldE =employeeRepo.findById(id).get();
		
       oldE.setEmpId(e.getEmpId());
       oldE.setName(e.getName());
       oldE.setDepartment(e.getDepartment());
       oldE.setBaseLocation(e.getBaseLocation());
       oldE.setCurrentLoacion(e.getCurrentLoacion());
       oldE.setPrimarySkills(e.getPrimarySkills());
       oldE.setSecondarySkills(e.getSecondarySkills());
       oldE.setSalary(e.getSalary());

		return employeeRepo.save(oldE);
	}
}
