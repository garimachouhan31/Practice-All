package com.yt.service;

import java.util.List;

import com.yt.model.Medicine;

public interface MedicineService {
	
	public Medicine saveMedicine(Medicine medicine);
	
	public List<Medicine> getAllMedicine(); 
	
	public Medicine getMedicineById(Integer id);
	
	public String deleteMed(Integer id);
}
