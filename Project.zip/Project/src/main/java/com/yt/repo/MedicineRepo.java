package com.yt.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yt.model.Medicine;

public interface MedicineRepo extends JpaRepository<Medicine , Integer> {

}
