import React from 'react'

function Home(props) {
    //console.log("Home", props)
    console.log("props", props)
    return (
        <div>
            {/* <div className='AddToCart'>
                <img src='./AddToCart.png' />
            </div> */}
            <h2>Home component</h2>
            <div className="cart-wrapper">
                <div className="img-wrapper item">
                    <img src='./iphone.png' />
                </div>

                <div className="text-wrapper item">
                    <span>
                        I-Phone
                    </span>
                    <span>
                        Price: $1000.00
                    </span>
                </div>

                <div className="btn-wrapper item">
                    <button onClick={
                        () => { props.addToCartHandler({ pice: 1000, name: 'i phone 11' }) }
                    }>Add To Cart</button>

                    <button className='removeToCart'
                     onClick={
                        () => { props.removeToCartHandler() }
                    }>Remove To Cart</button>
                </div>
            </div>
        </div>
    )
}
export default Home