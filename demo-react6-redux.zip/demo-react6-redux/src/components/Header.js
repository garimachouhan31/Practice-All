import React from 'react'
function Header(props)
{
    console.log(props.data)
    return(
        <div>
             <div className="AddToCart">
    <span className="cart-count">{props.data.length}</span>
                <img src="./AddToCart.png" />
            </div>
        </div>
    )
}

export default Header