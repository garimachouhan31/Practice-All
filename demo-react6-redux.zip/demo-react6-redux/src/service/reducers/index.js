import {combineReducers} from 'redux'
import cardItems from './Reducer'

export default combineReducers({
    cardItems,
})