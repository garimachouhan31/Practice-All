import { ADD_TO_CART } from "../constants"
import { REMOVE_TO_CART } from "../constants"

export const addToCart=(data)=>{
    console.log("action",data)
    return{
        type:ADD_TO_CART, // ye imp hoti he, jo data store hota he ye usme se btati he ki ye data kisse relate he like addtocart,removetocart etc
        data: data
    }
}

export const removeToCart=()=>{
    console.log("action")
    return{
        type:REMOVE_TO_CART, // ye imp hoti he, jo data store hota he ye usme se btati he ki ye data kisse relate he like addtocart,removetocart etc
       // data: data
    }
}