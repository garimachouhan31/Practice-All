import { useState } from "react"

function Post(){

    const [name, setName] = useState("");
    const [username, setUserName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [website, setWebsite] = useState("");


    function saveUser(){
        console.log(name, username, email, phone, website);

        const data = (name, username, email, phone, website);

        fetch("https://jsonplaceholder.typicode.com/users",{
            method:'POST',
            headers:{
                'Accept' : 'application/json',
                'Content-type':'application/json'
            },
            body:JSON.stringify(data)
        }).then((result)=>{
            // console.log("result" , result);
            result.json().then((resp)=>{
                console.warn("resp" , resp)
            })
        })
    }
    return(
        <div> 
            <h2>Post method </h2>
            <input type="text" value={name} onChange={(e)=>{setName(e.target.value)}} name="name"/><br/>
            <input type="text" value={username}  onChange={(e)=>{setUserName(e.target.value)}} name="username"/><br/>
            <input type="text" value={email} onChange={(e)=>{setEmail(e.target.value)}} name="email"/><br/>
            <input type="text" value={phone} onChange={(e)=>{setPhone(e.target.value)}} name="phone"/><br/>
            <input type="text" value={website} onChange={(e)=>{setWebsite(e.target.value)}} name="website"/><br/>
            <button type="button" onClick={saveUser}>save data</button>
        </div>
        
    )
}
export default Post