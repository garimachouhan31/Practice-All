import './App.css';
import GetMethod from './Get/GetMethod';
import Post from './Post/Post';

function App(){
  return(
    <div>
      <GetMethod/>
      <Post/>
    </div>
  )
}
export default App