
// import './App.css';
import React, {useEffect, useState} from 'react'


function GetMethod(){

    const [data, setData] = useState([]);
    // for update data
    const [name, setName] = useState("");
    const [username, setUserName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [website, setWebsite] = useState("");
    const [userId , setUserId]= useState(null); // for update


    useEffect(()=>{
        getList();
    },[])

    // console.log(data);

    // getmethod ka api code func me dala he taki refresh na karna padhe delete karne per

    function getList(){
        fetch("https://jsonplaceholder.typicode.com/users").then((result)=>{
            result.json().then((response)=>{
              console.log("result" , response);
              setData(response);
              setName(response[0].name);
              setUserName(response[0].username);
              setEmail(response[0].email);
              setPhone(response[0].phone);
              setWebsite(response[0].website);
              setUserId(response[0].userId);
            })
     })
    }

    // For delete method ::::--
     function deleteUser(id){
        alert(id);
        fetch(`https://jsonplaceholder.typicode.com/users/ ${id}` ,{
           method : 'DELETE'
       }).then((result)=>{
            result.json().then((resp)=>{
                console.log(resp);
                getList();
            })
        })
     }

     //for prefill user

     function PreFillUser(id){
       console.log(data[id-1]);

       let data1 = data[id-1];
              setName(data1.name);
              setUserName(data1.username);
              setEmail(data1.email);
              setPhone(data1.phone);
              setWebsite(data1.website);
              setUserId(data1.userId);

     }

     //for update
     function UpdateUser(){
        let user = {name, username, email, phone, website, userId};

        fetch(`https://jsonplaceholder.typicode.com/users/ ${userId}` ,{
            method : 'PUT',
            headers : {
                'Accept' : 'application/json',
                'Content-Type' : 'application/json'
            },
            body : JSON.stringify(user)
        }).then((result)=>{
             result.json().then((resp)=>{
                 console.log(resp);
                 getList();
             })
         })
     }
    
    return(
        <div>
            <h2>Get Method</h2>
            <table border="1">
              <tr>
                <td>Id</td>
                <td>Name</td>
                <td>UserName</td>
                <td>Email</td>
                {/* <td>Address</td> */}
                <td>phone</td>
                <td>website</td> 
                <td>Operations</td>
              </tr>
              {
                data.map((item)=>
                  <tr>
                  <td>{item.id}</td>
                  <td>{item.name}</td>
                  <td>{item.username}</td>
                  <td>{item.email}</td>
                  {/* <td>{item.address}</td> */}
                  <td>{item.phone}</td>
                  <td>{item.website}</td>

                  <td><button style={{margin:"2px"}} onClick={()=>deleteUser(item.id)}>Delete</button>
                  <button onClick={()=>PreFillUser(item.id)}>Update</button></td>
                </tr>
                )
              }
            </table>

            {/* for prefill data */}

            <div>
            <h2>Update Form</h2>
            <input type="text" value={name} onChange={(e)=>setName(e.target.value)}/><br/>
            <input type="text" value={username} onChange={(e)=>setUserName(e.target.value)} /><br/>
            <input type="text" value={email} onChange={(e)=>setEmail(e.target.value)}/><br/>
            <input type="text"  value={phone} onChange={(e)=>setPhone(e.target.value)}/><br/>
            <input type="text" value={website} onChange={(e)=>setWebsite(e.target.value)}/><br/>
            <button onClick={UpdateUser}>Update</button>
        </div>
        </div>
    )
}
export default GetMethod
