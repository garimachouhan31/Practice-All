
import './App.css';
import React , {BrowserRouter, Routes, Route}from 'react-router-dom';
import Home from './Router-Example-1/Home';
import About from './Router-Example-1/About';
import Navbar from './Router-Example-1/Navbar';
import Page404 from './Router-Example-1/Page404';
import ParamsDynamicRou from './Router-Example-1/Params-DynamicRou';
import SearchParam from './Router-Example-1/SearchParam';
import NestedRouting from './Nested-Routing/NestedRouting-7'
import Channel from './Nested-Routing/Channel';
import CompanyDetails from './Nested-Routing/CompanyDetails';
import Contact from './Nested-Routing/Contact';
import Login from './Protected-Route/Login';
import Protected from './Protected-Route/Protected';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
     <Navbar/>
        <Routes>

          {/* use login protected  */}
          <Route path="/" element={<Protected Component={Home}/>}/>


          <Route path="/about" element={<About/>}/>
          <Route path="/*" element={<Page404/>}/>
          <Route path="/user/:name" element={<ParamsDynamicRou/>}/>
          <Route path="/filter" element={<SearchParam/>}/>

          {/* /*for nested routing*/ }
          <Route path="/nested-Routing/" element={<NestedRouting/>}>
              <Route path="channel" element={<Channel/>}/>
              <Route path="company" element={<CompanyDetails/>}/>
              <Route path="contact" element={<Contact/>}/>
          </Route>

          <Route path="/login" element={<Login/>}/>
        </Routes>
      </BrowserRouter>
          </div>
  );
}

export default App;
