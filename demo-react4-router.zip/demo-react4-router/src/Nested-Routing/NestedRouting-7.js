import { Link, Outlet } from "react-router-dom"

function NestedRouting(){
    return(
        <div>
            <h2>Nested Routing</h2>
            
                <Link to="channel" style={{margin:"20px"}}>Channel</Link>  
                <Link to="contact" style={{margin:"20px"}}>Contact</Link>
                <Link to="company" style={{margin:"20px"}}>Company-Details</Link>
                <Outlet/>
           
        </div>
    )
}
export default NestedRouting