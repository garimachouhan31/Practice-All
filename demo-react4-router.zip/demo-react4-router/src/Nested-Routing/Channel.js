function Channel(){
    return(
        <div>
            <h2>Youtube channel page</h2>
            <p>YouTube is a free video sharing website that makes it easy to watch online videos. You can even create and upload your own videos to share with others. Originally created in 2005, YouTube is now one of the most popular sites on the Web, with visitors watching around 6 billion hours of video every month.</p>
        </div>
    )
}
export default Channel