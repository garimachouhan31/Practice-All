function Contact(){
    return(
        <div>
            <h2>this is contact page</h2>
            <h4>contact numbers</h4>
            <p>95665677338</p>
            <p>97542345679</p>
            <p>89064345678</p>
            <p>7856789045</p>
            
        </div>
    )
}
export default Contact