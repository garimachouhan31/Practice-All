function CompanyDetails(){
    return(
        <div>
            <h2>Company Details page</h2>
            <p>A company is a legal entity formed by a group of individuals to engage in and operate a business—commercial or industrial—enterprise. A company may be organized in various ways for tax and financial liability purposes depending on the corporate law of its jurisdiction.</p>
        </div>
    )
}
export default CompanyDetails