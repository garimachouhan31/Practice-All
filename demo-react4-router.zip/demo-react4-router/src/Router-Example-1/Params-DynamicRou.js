import { Link, useParams } from "react-router-dom"

function ParamsDynamicRou(){
const params = useParams();
const {name}=params;

    return(
        <div>
            <h2>Params || Dynamic Routing PAGE</h2>
            <h3>this is {name} page</h3>
            <Link to="/">Go to Home Page</Link>
            
        </div>
    )
}
export default ParamsDynamicRou