import React, {  NavLink } from 'react-router-dom';

function Navbar() {
    return (
        <div>
            {/* link add */}
            <ul className='navbar'>
                <li><NavLink className="navbar-link" to="/" ><b>Home</b></NavLink></li>
                <li><NavLink className="navbar-link" to="/about"><b>About</b></NavLink></li>
                <li><NavLink className="navbar-link" to="/filter"><b>Filter</b></NavLink></li>
                <li><NavLink className="navbar-link" to="/Nested-Routing"><b>Nested-Routing</b></NavLink></li>
                <li><NavLink className="navbar-link" to="/login"><b>Login</b></NavLink></li>

            </ul>
        </div>
    )
}
export default Navbar