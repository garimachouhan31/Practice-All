import { Link, useSearchParams } from "react-router-dom"

function SearchParam(){
    const[search, setSearch]=useSearchParams();

    console.log(search.get('age'));
    console.log(search.get('city'));

    const age = search.get('age');
    const city =search.get('city');
        return(
        <div>
            <h2>Search params hook </h2>
            <h1>Filter page</h1>
   {/* for get data */}
            <h4>Age is : {age}</h4>
            <h4>City is : {city}</h4>

            {/* for set data */}
            <button onClick={()=>setSearch({age : 40})}>setparam data </button>

            {/* set another input text */}
            <input type="text" onChange={(e)=>setSearch({text : e.target.value , age:20})} placeholder="set text please"/>

            <br/>
            <Link to="/">Go to Home Page</Link>
           
        </div>
    )
}
export default SearchParam