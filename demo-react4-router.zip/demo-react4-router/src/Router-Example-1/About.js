import { Link } from "react-router-dom"

function About(){
    return(
        <div>
            <h2>About PAGE</h2>
            <Link to="/">Go to Home Page</Link>
           
        </div>
    )
}
export default About