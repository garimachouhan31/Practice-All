import { Link, useNavigate } from "react-router-dom"

function Home() {

    const navigate = useNavigate();

    const navFun=()=>{
        navigate("/filter");
    }
    return (
        <div>
            <h2>HOME PAGE</h2>


            <h4>Users Details page</h4>
            <li><Link to="/user/garima">Garima(User)</Link></li>
            <li><Link to="/user/payal">payal(User)</Link></li>
            <li><Link to="/user/gourav">gourav(User)</Link></li>
            <h4> For Navigation with route </h4>
            <button onClick={()=>navigate("/about")}>Go to About</button><br></br>

            <h4>For navigation with function</h4>
            <button onClick={()=>navFun()}>Go to Filter</button>

        </div>
    )
}
export default Home