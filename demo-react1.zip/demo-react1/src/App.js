
import './App.css';
import FunctionalC from './components/FunctionalC-1';
import ClassC from './components/ClassC-2';
import OnclickEvent from './components/OnclickEvent-3';
import WithFunctionalCState from './components/WithFunctionalCState-4';
import WithClassCState from './components/WithClassCState-5';
import WithFunCProps from './components/WithFunCProps-6';
import WithClassCProps from './components/WithClassCProps-7';
import InputBox from './components/InputBox-8';
import HideShow from './components/Hide&Show-9';
import Form from './Form/Form-10';
import IfCondition from './Form/IfCondition-11';
import BasicFormValidat from './Form/BasicFormValidat-12';
import User   from './Props-as-function/User';
import Student from './Props-as-function/Student-13';
function App() {
// is function ko humne main file me bnanaya ha is liye hum isko props ke through kisi bhi file me use kar sakte hai
  function getData() {
    alert("Hello from app component")
  }

  return (
    <div className="App">
     <h3>I am App file</h3>
      <FunctionalC/>
      <ClassC/>
      <OnclickEvent/>
      <h4>state funtions-------</h4>
      <WithFunctionalCState/>
      <WithClassCState/>
      <h4>Props----------</h4>
      <h5>I am using in functional component</h5>     
       <WithFunCProps name = {"garima"} email = {"gar@gmail.com"} other = {{add : "delhi", mob : 123}}/>
      <WithFunCProps name = {"gourav"} email = {"gour@gmail.com"} other = {{add : "indore", mob : 321}}/>
      <h5>I am using in class component</h5>
      <WithClassCProps name = "payal" email = "py@gmail.com"/>
      <WithClassCProps name = "pihu" email = "pr@gmail.com"/>
      <InputBox/>
      <HideShow/>
      <br></br>
      <Form/>
       <br></br>
       <IfCondition/>
       <br></br>
       <BasicFormValidat/>
       <User  data={getData} />
     <Student data={getData} />
    </div>
  );
}

export default App;
