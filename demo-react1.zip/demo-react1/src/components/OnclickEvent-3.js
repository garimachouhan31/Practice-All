function OnclickEvent() {
    function apple(){
        alert("hello");
    }
    return (
      <div>
        <h4>onClick funtion</h4>
       <button onClick={apple}>click</button>
      </div>
    );
  }
  export default OnclickEvent;