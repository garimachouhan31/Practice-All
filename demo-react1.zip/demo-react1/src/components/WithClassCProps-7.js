import React from 'react'

class WithClassCProps extends React.Component{
    render(){
       return(
        <div style={{backgroundColor: 'red'}}>
            <h5>{this.props.name}</h5>
            <h6>{this.props.email}</h6>
            </div>
       ) 
    }
}
export default WithClassCProps;