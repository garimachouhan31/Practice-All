import React,{useState} from 'react'

function InputBox(){
    const [data, setData] = useState(null)
    const [print, setPrint] = useState(false)
    function getData(val){
        console.log(val.target.value)
        setData(val.target.value)
        setPrint(false)
    }
    return(
        <div>
            <h3>Get input box value</h3>
          {
            print?
            <h5>{data}</h5>
            :null
          }
            <input type="text" onChange={getData}/>
            <button onClick={()=>setPrint(true)}>print Data</button>
        </div>
    )
}
export default InputBox;