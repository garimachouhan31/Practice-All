import React from 'react';

class ClassC extends React.Component{
    render(){
        return(
            <div>
            <h5>I am class component ==== {10*20} multiple two num</h5>
            {/* <h6>{10*20}</h6> */}
            </div>
        )
    }
}
export default ClassC;