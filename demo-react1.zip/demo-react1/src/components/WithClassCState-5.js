import React from 'react';

class WithClassCState extends React.Component {

    constructor(){
        super();
        this.state={
            data:"garima",
            num : 1
        }
    }
    apple(){
        alert("apple");
        this.setState({data : "apple"});
    }
    appleNum(){
        this.setState({num : this.state.num + 1})
    }
   render(){
    return (
        <div className="App">
         <h6>I am class state</h6>
         <h4>{this.state.data}</h4>
          <button onClick={()=>this.apple()}>class state</button>
          <h4>{this.state.num}</h4>
          <button onClick={()=>this.appleNum()}>class Increase Num</button>
        </div>
      );
   }
  }
  export default WithClassCState;