function FunctionalC(){
    return(
        <div>
            <h5>Hellon I am functional component ==== {10+20} add two num </h5>
            {/* <h6>{10+20}</h6> */}
        </div>
    )
}
export default FunctionalC;