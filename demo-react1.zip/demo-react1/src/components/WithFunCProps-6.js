// import React,{useState} from "react";

function WithFunCProps (props){
    return(
        <div style={{backgroundColor : "skyblue"}}>
            <h6> Hello {props.name}</h6>
            <h6>Email : {props.email}</h6>
            <h6>Address : {props.other.add}</h6>
            <h6>Address : {props.other.mob}</h6>
        </div>
    )
}
export default WithFunCProps;