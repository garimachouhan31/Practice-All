//using varible update but we cannot update the data of varible

// function State() {
//     let data = 'garima';
//     function update(){
//        data = 'gourav'; 
//         alert(data);
//     }
//     return (
//       <div>
//         <h3>{data}</h3>
//        <button onClick={update}>update Data</button>
//       </div>
//     );
//   }

//using props for update data

import { useState } from "react";
function State() {
      const [data, setData] = useState("GARIMA");
      const [num, setNum] = useState(0);
        function update(){
           setData("CHOUHAN")
        }
        function updateNum(){
          setNum(num + 1)
       }
        return (
          <div>
           <h5>{data}</h5> 
           <button onClick={update}>functional state</button>
           <h5>{num}</h5>
           <button onClick={updateNum}>Increase</button>
          </div>
         );
       }
  export default State;