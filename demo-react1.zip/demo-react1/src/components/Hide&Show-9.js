import React, { useState } from "react";

function HideShow(){
    const [status, setStatus] = useState(true)
    return(
        <div>
            {
                status?<h5>Hide & show </h5>:null
            }
            
            <button onClick={()=>setStatus(false)}>Hide</button>
            <button onClick={()=>setStatus(true)}>show</button>
            <button onClick={()=>setStatus(!status)}>toggle</button>
        </div>
    )
}
export default HideShow;