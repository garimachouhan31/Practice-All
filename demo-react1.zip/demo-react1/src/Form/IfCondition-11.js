import React, {useState} from "react";

function IfCondition(){
    // const [loggedIn, setLoggedIn] = useState(false)
    const [loggedIn, setLoggedIn] = useState(1)

    // if(loggedIn){
    //     return(
    //         <div>
    //            <h6>welcome garima</h6>
    //         </div>
    //     )
    // }
    // else{
    //    return(
    //     <div>
    //     <h6>welcome guest</h6>
    //  </div>
    //    )
    // }  // this type is complicated


    //if or else
    // return(
    //     <div>
    //         {
    //             loggedIn?<h5>welcome GARIMA</h5>:<h5>welcome GUEST</h5>
    //         }
    //     </div>
    // )

    //multiple condition like nested if and ternary operator
    return(
        <div>
            {
                loggedIn==1?<h5>welcome GARIMA</h5>:loggedIn==2?<h5>welcome GOURAV</h5>:<h5>welcome GUEST</h5>
            }
        </div>
    )
}


export default IfCondition;