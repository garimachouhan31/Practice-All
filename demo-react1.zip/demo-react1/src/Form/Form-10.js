import { useState } from "react";

function Form(){
    const [name, setName] = useState("");
    const [option, setOption] = useState("");
    const [tnc, setTnc] = useState(false);
    function getFormData(e){
        e.preventDefault(e)
        console.log(name,option,tnc);
    }
    return(
        <div>
         <h2>FORM</h2>
         <h4>handle form in react</h4>
         <form onSubmit={getFormData}>
            <input type="text" placeholder="Enter name" onChange={(e)=>setName(e.target.value)}/><br/>
            <select  onChange={(e)=>setOption(e.target.value)}>
                <option>select option</option>
                <option>delhi</option>
                <option>agra</option>
            </select><br/>

            <input type="checkbox"  onChange={(e)=>setTnc(e.target.checked)}/><span>accept term & conditions</span><br></br>
            <button type="submit">submit</button>
         </form>
          
        </div>
    )
}
export default Form;