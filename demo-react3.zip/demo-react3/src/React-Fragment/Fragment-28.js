function Fragment() {
    return (
        <>
            <td>Garima</td>
            <td>Gourav</td>
        </>
    )
}

export default Fragment;