
import React from 'react'
import Fragment from './Fragment-28';

function App2() {
  return (
    <>
      <h5>React Fragment</h5>
     <table>
       <tbody>
         <tr>
         
          <Fragment/>
          <Fragment/>
          <Fragment/>
          <Fragment/>


         </tr>
       </tbody>
     </table>
      </>
      
  );
}

export default App2;