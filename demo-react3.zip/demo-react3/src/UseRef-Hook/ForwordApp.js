
import React ,{useRef} from 'react'
import ForwordRef35 from './ForwordRef-35';

function ForwordApp() {
  let inputRef=useRef(null)
  function updateInput()
  {
    inputRef.current.value="1000";
    inputRef.current.style.color="red"
    inputRef.current.focus()


  }
  return (
    <div className="App">
     
      <ForwordRef35 ref={inputRef} />
      <button onClick={updateInput} >Update Input Box</button>
    </div>
  );

}
export default ForwordApp;