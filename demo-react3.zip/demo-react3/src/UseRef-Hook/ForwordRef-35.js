import React,{forwardRef} from 'react'
function ForwordRef(props,ref)
{
    return(
        <div>
            <input ref={ref} type="text" />
        </div>
    )
}

export default forwardRef(ForwordRef);