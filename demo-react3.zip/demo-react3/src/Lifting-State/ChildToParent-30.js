function ChildToParent(props)
{
    const name="GARIMA CHOUHAN"
    return(
        <div>
            <h3>ChildToParent</h3>
            <h4>User Name is : </h4>
            <button onClick={()=>props.getData(name)} >Click Me</button>
        </div>
    )
}

export default ChildToParent;