import React from 'react'
import ChildToParent from './ChildToParent-30';
import ParentToChild from './ParentToChild-29';
function App3() {

    //P T C
    let data = "Gourav"

    //C T P
  function getName(name)
  {
    alert(name)
  }
  return (
    <div className="App">
      
      <ChildToParent getData={getName} />

      {/* //P T C */}

      <ParentToChild  name = {data}/>
    </div>
  );
}

export default App3;