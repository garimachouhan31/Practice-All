function parentToChild(props){
 return(
    <div>
        <h3>ParentToChild</h3>
        <h4>user name : {props.name}</h4>
        <button >click</button>
    </div>
 )
}
export default parentToChild