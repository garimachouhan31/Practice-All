
import './App.css';
import App4 from './Pure-useMemo-component/App4';
import App3 from './Lifting-State/App3';
import App2 from './React-Fragment/App2';
import App1 from './Reuse-Component/App1';
import UseMemo from './Pure-useMemo-component/UseMemo-32';
import Ref from './UseRef-Hook/Ref-33';
import UseRef from './UseRef-Hook/UseRef-34';
import ForwordApp from './UseRef-Hook/ForwordApp';
import Controlled from './Controlled-Uncon/Controlled-36';
import Uncontrolled from './Controlled-Uncon/Uncontrolled-37';
import HOC from './Controlled-Uncon/HOC-38';


function App() {
  return (
    <div className="App">
     <h2>Reuse component</h2>
       <App1/>

      <h2>React Fragment</h2>
      <App2/>

      <h2>Send data child to parent and parent to child component / Lifting State</h2>
      <App3/>

      <h2>Pure component</h2>
      <App4/>

      <h2>Use memo hook</h2>
      <UseMemo/>

      <h2>Ref - Example</h2>
      <Ref/>

      <h2>UseRef Hook</h2>
      <UseRef/>

      <h2>Forword Ref</h2>
      <ForwordApp/>

      <h2>Controlled component</h2>
      <Controlled/>

      <h2>Uncontrolled component</h2>
      <Uncontrolled/>

      <h2> High Order Component (HOC)</h2>
      <HOC/>
        
    </div>
  );
}

export default App;
