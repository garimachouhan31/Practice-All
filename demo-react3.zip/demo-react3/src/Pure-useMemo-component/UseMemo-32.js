
import React, { useState } from 'react'
function UseMemo() {
  const [count, setData] = useState(1)
  const [item, setItem] = useState(20)

  const newApple=React.useMemo(
    function appleTime() {
      console.warn("Hello")
      return 100 * count;
    }
  ,[count])
  return (
    <div className="App">
      <h4>Hooks in React </h4>
      <h4>count : {count}</h4>
      <h4>item : {item}</h4>
      {newApple}
      <button onClick={() => setData(count + 1)}>Update State</button>
      <button onClick={() => setItem(item * 10)}>Update State</button>

    </div>
  );
}

export default UseMemo;